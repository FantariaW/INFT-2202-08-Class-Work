// function that returens express object / app
const express = require("express");
// calling
const app = express();

// Configuration
app.set("views", "./views");

app.set("view engine", "ejs");

//display home page data from home.ejs
app.get("/home", function(request, response){
    
    console.log(`Server has received a request a ${request.url}`);
    response.render("home.ejs")
    // response.send("Hello World");
});

// app.listen
app.listen(3500, ()=> {
    console.log(`Express server listening on port 3500...`);
});
